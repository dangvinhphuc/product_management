import com.google.gson.Gson;

import java.io.FileNotFoundException;

public class MyStack extends MyList {
    public MyStack() {
        this.setHead(null);
        this.setSize(0);
    }

    public void push(Product product) {// phần tử mới sẽ đưa vào cuối danh sách
        Node node = new Node(product);
        if (this.getSize() == 0) {
            this.setHead(node);
        } else {
            Node last = this.nodeAt(this.getSize() - 1);
            last.setNext(node);
        }
        this.setSize(this.getSize() + 1);
    }

    public Node pop() {//lấy phần tử cuối, sau đó xóa phần tử cuối
        Node popNode = this.nodeAt(getSize() - 1);
        this.deleteNodeAt(this.getSize() - 1);
        return popNode;
    }

    public void getItemsFromFile(String fileName) throws FileNotFoundException {// như trong MyList
        Gson gson = new Gson();
        Product product;
        String dataNotSplit = this.readFile(fileName);
        if (dataNotSplit != "") {
            String[] dataSplit = dataNotSplit.split("\n");
            for (int i = 0; i < dataSplit.length; i++) {
                product = gson.fromJson(dataSplit[i], Product.class);
                this.push(product);// điều chỉnh phương thức đưa vào list
            }
        }
    }

    @Override
    public void display() {
        System.out.printf("%-8s%-12s%-30s%-14s%-16s", "Order", "| ID", "| Name", "| Quantity", "| Price");
        System.out.println();
        for (int i = 0; i < 80; i++) {
            System.out.print("-");
        }
        System.out.println();
        int count = 1;
        while (this.getSize() > 0) {
            System.out.printf("%-8d", count);
            pop().display();
            count++;
        }
    }

}
