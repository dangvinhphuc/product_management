public class MyQueue extends MyStack {
    public MyQueue() {
        this.setHead(null);
        this.setSize(0);
    }

    public void enqueue(Product product) {
        super.push(product);//thừa hưởng từ lớp cha (MyStack)
    }

    public Node dequeue() {//lấy Node đầu tiên, sau đó xóa khỏi list
        Node dequeueNode = this.getHead();
        this.deleteNodeAt(0);
        return dequeueNode;
    }

    @Override
    public void display() {
        System.out.printf("%-8s%-12s%-30s%-14s%-16s", "Order", "| ID", "| Name", "| Quantity", "| Price");
        System.out.println();
        for (int i = 0; i < 80; i++) {
            System.out.print("-");
        }
        System.out.println();
        int count = 1;
        while (this.getSize() > 0) {
            System.out.printf("%-8d", count);
            dequeue().display();//điều chỉnh khác so với lớp cha
            count++;
        }
    }
}
