import com.google.gson.Gson;

import java.io.*;
import java.util.Scanner;

public class MyList {
    private Node head;
    private int size;

    public MyList() {
        head = null;
        size = 0;
    }

    public Node getHead() {
        return head;
    }

    public void setHead(Node head) {
        this.head = head;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void getItemsFromFile(String fileName) throws FileNotFoundException {
        this.clearList();
        Gson gson = new Gson();
        Product product;
        String dataNotSplit = readFile(fileName);
        if (dataNotSplit != "") {
            String[] dataSplit = dataNotSplit.split("\n");
            for (int i = 0; i < dataSplit.length; i++) {
                product = gson.fromJson(dataSplit[i], Product.class);
                this.addLast(new Node(product));
            }
        }
    }

    public String readFile(String fileName) {// đọc nội dung String từ file
        String data = "";
        try {
            FileReader fileReader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            int i;
            while ((i = bufferedReader.read()) != -1) {
                data += (char) i;
            }
            bufferedReader.close();
            fileReader.close();
        } catch (Exception e) {
        }
        return data;
    }

    public void clearList() {
        for (int i = 0; i < size; i++) {
            this.deleteNodeAt(0);
        }
    }

    public void addProduct() {
        Product product = new Product();
        System.out.print("Input new ID: ");
        product.setCode(inputString());
        System.out.print("Input Product's name: ");
        product.setName(inputString());
        System.out.print("Input Product's quantity: ");
        product.setQuantity(inputInt());
        System.out.print("Input Product's price: ");
        product.setPrice(inputInt());
        Node node = new Node(product);
        this.addLast(node);
        System.out.println("SUCCESS!\n");
    }

    public void addLast(Node node) {//thêm item mới vào cuối danh sách
        if (size == 0) {
            head = node;
        } else {
            this.nodeAt(size - 1).setNext(node);
        }
        size++;
        this.nodeAt(size - 1).setNext(null);
    }


    public void display() {
        Node current = head;
        System.out.printf("%-8s%-12s%-30s%-14s%-16s", "Order", "| ID", "| Name", "| Quantity", "| Price");
        System.out.println();
        for (int i = 0; i < 80; i++) {
            System.out.print("-");
        }
        System.out.println();
        for (int i = 0; i < size; i++) {
            System.out.printf("%-8d", i + 1);
            current.display();
            current = current.getNext();
        }
    }


    public void writeAllItemsToFile(String fileName) {
        Node current = head;
        Gson gson = new Gson();
        String data = "";
        for (int i = 0; i < size - 1; i++) {
            data += gson.toJson(current.getInfo());
            data += "\n";// các node trước node cuối cùng có xuống dòng
            current = current.getNext();
        }
        data += gson.toJson(this.nodeAt(size - 1).getInfo());//Node cuối khôgn xuống dòng
        this.writeToFile(data, fileName, false);
        System.out.println("Successfully!");

    }

    public void writeToFile(String data, String fileName, boolean writeContinue) {
        try {
            FileWriter fileWriter = new FileWriter(fileName, writeContinue);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
            bufferedWriter.write(data);
            bufferedWriter.close();
            fileWriter.close();
        } catch (Exception e) {
        }
    }

//    public void clearFile(String fileName) {
//        try {
//            FileWriter fileWriter = new FileWriter(fileName, false);
//            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//            bufferedWriter.write("");
//            bufferedWriter.close();
//            fileWriter.close();
//        } catch (Exception e) {
//        }
//    }


    public void searchByCode() {
        String searchID;
        System.out.print("Input the ID to search: ");
        searchID = inputString().toLowerCase();
        System.out.println("Result:\n");
        System.out.printf("%-8s%-12s%-30s%-14s%-16s", "Order", "| ID", "| Name", "| Quantity", "| Price");
        System.out.println();
        Node current = head;
        int count = 0;
        String code;
        for (int i = 0; i < size; i++) {
            code = current.getInfo().getCode().toLowerCase();
            if (code.contains(searchID)) {
                count++;
                System.out.printf("%-8d", count);
                current.display();
            }
            current = current.getNext();
        }
        if (count == 0) {
            System.out.print(-1);
        }
    }

    public void deleteByCode() {
        this.display();
        String deleteCode;
        System.out.print("Input the bcode to delete: ");
        deleteCode = inputString();
        Node current = head;
        for (int i = 0; i < size; i++) {
            if (current.getInfo().getCode().equalsIgnoreCase(deleteCode)) {
                this.deleteNodeAt(i);
                i--;
            }
            current = current.getNext();
        }
        System.out.println("Successful!");
        this.display();
    }


    public void deleteNodeAt(int index) {// xóa node tại vị trí bất kỳ trong list
        if (index >= 0 && index <= size - 1) {
            if (size == 1) {
                this.head = null;
            } else {
                if (index == 0) {
                    this.head = this.head.getNext();
                } else if (index == size - 1) {
                    this.nodeAt(size - 2).setNext(null);
                } else {
                    this.nodeAt(index - 1).setNext(this.nodeAt(index + 1));
                }
            }
        }
        this.size--;
    }

    public Node nodeAt(int index) {// lấy thông tin của Node tại vị trí bất kỳ trong list
        if (size == 0 || index > size - 1) {
            return null;
        } else {
            Node nodeFound = this.head;
            for (int i = 0; i < index; i++) {
                nodeFound = nodeFound.getNext();
            }
            return nodeFound;
        }
    }

    public void sortByCode() {//sắp xếp chỉ hoán đổi data, không hoán đổi next
        int index;
        String codeJ;
        String codeIndex;
        for (int i = 0; i < size - 1; i++) {// sắp xếp theo kiểu selection sort
            index = i;
            codeIndex = this.nodeAt(index).getInfo().getCode();
            for (int j = i + 1; j < size; j++) {
                codeJ = this.nodeAt(j).getInfo().getCode();
                if (codeJ.compareTo(codeIndex) < 0) {
                    index = j;
                }
            }
            this.swap(i, index);
        }
        this.display();
    }

    public void swap(int i, int j) {
        Product productI = this.nodeAt(i).getInfo();
        Product productJ = this.nodeAt(j).getInfo();
        Product productTmp = productI;
        this.nodeAt(i).setInfo(productJ);
        this.nodeAt(j).setInfo(productTmp);
    }

    public void showConvertToBinary() {
        int quantity = head.getInfo().getQuantity();
        System.out.print("Quantity = " + quantity + " => ");
        convertToBinary(quantity);
    }

    public void convertToBinary(int numberDEC) {
        if (numberDEC > 0) {
            int mod = numberDEC % 2;
            convertToBinary(numberDEC / 2);
            System.out.print(mod);
        }
    }


    /////////////các phương thức phụ trợ
    public static int inputInt() {
        Scanner sc = new Scanner(System.in);
        int input;
        while (true) {
            try {
                input = Integer.parseInt(sc.nextLine());
                break;
            } catch (Exception e) {
                System.out.println("Please input number: ");
            }
        }
        return input;
    }

    public static String inputString() {
        Scanner sc = new Scanner(System.in);
        String input = sc.nextLine();
        return input;
    }


}
