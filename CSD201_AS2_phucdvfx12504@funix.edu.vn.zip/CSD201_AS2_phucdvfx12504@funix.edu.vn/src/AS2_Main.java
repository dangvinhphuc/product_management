import java.io.FileNotFoundException;

public class AS2_Main extends MyList {
    private static MyList myList = new MyList();
    private static String fileName = "data.txt";
    private static MyStack myStack = new MyStack();
    private static MyQueue myQueue = new MyQueue();
    private static int choice;
    private static int confirmContinue = 1;


    public static void main(String[] args) throws FileNotFoundException {
        while (confirmContinue == 1) {
            menu();
            if (choice > 0) {
                switch (choice) {
                    case 1:
                        myList.getItemsFromFile(fileName);
                        myList.display();
                        break;
                    case 2:
                        myList.addProduct();
                        break;
                    case 3:
                        myList.display();
                        break;
                    case 4:
                        myList.writeAllItemsToFile(fileName);
                        break;
                    case 5:
                        myList.searchByCode();
                        break;
                    case 6:
                        myList.deleteByCode();
                        break;
                    case 7:
                        myList.sortByCode();
                        break;
                    case 8:
                        myList.showConvertToBinary();
                        break;
                    case 9:
                        myStack.getItemsFromFile(fileName);
                        myStack.display();
                        break;
                    case 10:
                        myQueue.getItemsFromFile(fileName);
                        myQueue.display();
                        break;
                }
                confirmContinue();
            } else {
                confirmContinue = 2;
            }
        }
        System.out.println("Thanks!");
    }


    public static void menu() {
        System.out.println("Choose one of this options:");
        System.out.println("Product list:");
        System.out.println("1. Load data from file and display");
        System.out.println("2. Input & add to the end");
        System.out.println("3. Display data");
        System.out.println("4. Save product list to file.");
        System.out.println("5. Search by ID");
        System.out.println("6. Delete by ID");
        System.out.println("7. Sort by ID.");
        System.out.println("8. Convert to Binary");
        System.out.println("9. Load to stack and display");
        System.out.println("10. Load to queue and display.");
        System.out.println("0. Exit");
        System.out.print("CHOICE = ");
        choice = inputInt();
        while (choice < 0 || choice > 10) {
            System.out.println("Input from 0 - 10: ");
            choice = inputInt();
        }
        System.out.println();
    }

    public static void confirmContinue() {
        System.out.println();
        System.out.println("Continue?");
        System.out.println("1. YES");
        System.out.println("2. NO");
        confirmContinue = inputInt();
        while (confirmContinue < 1 || confirmContinue > 2) {
            System.out.print("Input from 1 or 2: ");
        }
        System.out.println();
    }


}
