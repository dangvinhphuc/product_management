public class Node {
    private Product info;
    private Node next;

    public Node() {
        info = null;
        next = null;
    }

    public Node(Product info) {
        this.info = info;
        next = null;
    }

    public Product getInfo() {
        return info;
    }

    public void setInfo(Product info) {
        this.info = info;
    }

    public Node getNext() {
        return next;
    }

    public void setNext(Node next) {
        this.next = next;
    }

    public void display() {
        String code = info.getCode();
        String name = info.getName();
        int quantity = info.getQuantity();
        int price = info.getPrice();
        System.out.printf("%-12s%-30s%-14s%-16s", "| " + code, "| " + name, "| " + quantity, "| " + price);
        System.out.println();
    }
}
